import sys
import pandas as pd

df = pd.read_csv(sys.argv[1], low_memory=False)

print("UNIQUE COUNTS")
for c in ["content_id", "creator_id", "creator_name"]:
    print(f"{c}: {df[c].nunique()}")
print("duplicate content_id rows:", df.duplicated("content_id").sum())

g = df.groupby("creator_id")
posts = g.size()
print("\nPOSTS PER CREATOR")
print(posts.describe().to_string())

print("\nCONSISTENCY ACROSS A CREATOR'S POSTS (creators with 2+ posts)")
eligible = posts >= 2
for c in ["creator_name", "platform", "content_category", "follower_count",
          "audience_age_distribution", "audience_gender_distribution",
          "audience_location", "language"]:
    multi = g[c].nunique() > 1
    print(f"{c}: {multi[eligible].mean():.1%} have more than one distinct value")
names = df.groupby("creator_name")["creator_id"].nunique()
print(f"creator_name shared by several creator_ids: {(names > 1).mean():.1%}")

print("\nDATES")
d = pd.to_datetime(df["post_date"], format="%m/%d/%y %I:%M %p", errors="coerce")
print("unparseable dates:", d.isna().sum())
print("range:", d.min(), "to", d.max())
print(d.dt.to_period("M").value_counts().sort_index().to_string())

print("\nINVALID VALUES")
print("likes > views:", (df.likes > df.views).sum())
print("zero or negative follower_count:", (df.follower_count <= 0).sum())

print("\nCORRELATIONS")
num = ["views", "likes", "shares", "comments_count", "follower_count", "content_length"]
print(df[num].corr().round(3).to_string())

eng = (df.likes + df.comments_count + df.shares) / df.views
print("\nENGAGEMENT (likes+comments+shares)/views:")
print(eng.describe().to_string())

cols = ["views", "likes", "shares", "comments_count", "follower_count"]
for by in ["is_sponsored", "platform", "content_category"]:
    print(f"\nMEANS BY {by}")
    print(df.groupby(by)[cols].mean().round(1).to_string())